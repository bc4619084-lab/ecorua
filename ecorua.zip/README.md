# EcoRua ♻️
Aplicativo informativo sobre coleta de lixo e separação de resíduos — projeto de extensão em **Economia Sustentável**.

## 🚀 Tecnologias
- React + Vite
- TailwindCSS
- LocalStorage (dados locais)
- Notifications API (alertas de coleta)

## 💡 Funcionalidades
- Calendário de coleta (configurável por dia e tipo de resíduo)
- Guia de separação de lixo
- Seção de ofertas/trocas entre vizinhos
- Lembrete diário de coleta
- Armazenamento local (sem servidor)

## 🧩 Como rodar localmente
```bash
git clone https://github.com/SEU_USUARIO/ecorua.git
cd ecorua
npm install
npm run dev
```

## 🌍 Publicar na Vercel
1. Criar conta gratuita em [https://vercel.com](https://vercel.com)
2. Conectar ao teu GitHub
3. Importar o repositório `ecorua`
4. Deploy automático (Vercel detecta o Vite)

---

Desenvolvido por **[Seu Nome]** — estudante de ADS.
