// App.jsx conteúdo completo deve ser colado aqui (ver canvas EcoRua)
